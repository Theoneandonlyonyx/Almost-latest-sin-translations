package net.mikexxx.pmpext;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraftforge.fml.loading.FMLPaths;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Colour categories for the "All Plants" tab. On first start the file
 * config/pmp_mikexxx/plant_colors.json is created from the built-in defaults. Edit it to move plants
 * between categories (ids without the namespace). Plants that are missing from the file are added to "other".
 */
public final class ColorConfig {
    public static final String[] KEYS = {"burgundy", "red", "orange", "yellow", "green", "blue", "cyan", "purple", "pink", "white", "other"};
    private static final Map<String, List<String>> CATS = new LinkedHashMap<>();
    private static final List<String> ALL = new ArrayList<>();
    private static boolean loaded = false;

    private ColorConfig() {}

    private static JsonObject readDefaults() {
        try (InputStream in = ColorConfig.class.getResourceAsStream("/pmp_colors.json")) {
            if (in == null) return new JsonObject();
            return JsonParser.parseReader(new InputStreamReader(in, StandardCharsets.UTF_8)).getAsJsonObject();
        } catch (Exception e) {
            return new JsonObject();
        }
    }

    private static List<String> list(JsonObject o, String key) {
        List<String> out = new ArrayList<>();
        if (o.has(key) && o.get(key).isJsonArray()) {
            for (JsonElement e : o.getAsJsonArray(key)) out.add(e.getAsString());
        }
        return out;
    }

    public static synchronized void load() {
        if (loaded) return;
        loaded = true;
        JsonObject defaults = readDefaults();
        JsonObject user = defaults;
        try {
            Path dir = FMLPaths.CONFIGDIR.get().resolve("pmp_mikexxx");
            Path file = dir.resolve("plant_colors.json");
            if (!Files.exists(file)) {
                Files.createDirectories(dir);
                JsonObject out = new JsonObject();
                out.addProperty("_info", "Edit the lists to move plants between colour filters of the PMP 'All Plants' creative tab. "
                        + "Use item ids without 'pmp_mikexxx:'. Delete this file to restore the defaults. Plants not listed anywhere go to 'other'.");
                for (String k : KEYS) {
                    JsonArray a = new JsonArray();
                    for (String id : list(defaults, k)) a.add(id);
                    out.add(k, a);
                }
                Gson gson = new GsonBuilder().setPrettyPrinting().create();
                Files.write(file, gson.toJson(out).getBytes(StandardCharsets.UTF_8));
                user = out;
            } else {
                try (Reader r = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
                    user = JsonParser.parseReader(r).getAsJsonObject();
                }
            }
        } catch (Exception e) {
            user = defaults;
        }
        Set<String> seen = new LinkedHashSet<>();
        for (String k : KEYS) {
            List<String> l = new ArrayList<>();
            for (String id : list(user, k)) {
                if (seen.add(id)) l.add(id);
            }
            CATS.put(k, l);
        }
        // everything from the default list that the user file forgot goes to "other"
        List<String> defAll = list(defaults, "all");
        for (String id : defAll) {
            if (seen.add(id)) CATS.get("other").add(id);
        }
        Set<String> all = new LinkedHashSet<>(defAll);
        for (String k : KEYS) all.addAll(CATS.get(k));
        ALL.addAll(all);
    }

    public static List<String> all() {
        load();
        return ALL;
    }

    public static List<String> category(String key) {
        load();
        if ("all".equals(key)) return ALL;
        List<String> l = CATS.get(key);
        return l == null ? new ArrayList<>() : l;
    }
}
