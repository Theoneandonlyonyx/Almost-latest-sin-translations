# PMP port 1.3.0

Build: same workflow as before. Use the jar WITHOUT "-ext" (build/libs/PlantMegaPack-mikexxx-port-1_20_1-1.3.0.jar).

## Hanging plants (rebuilt)
- Original textures only, no extra chain block. Big 1.7.10/1.6.4 plants: 2 blocks (top with hanger, bottom with plant/bowl), item icon = the small texture.
- 1.12.2 vines + "Hanging Sweet Peas (colour)" (the finer flowers): 3 blocks (top / middle / bottom).
- Hang from ceilings, leaves, vanilla chains, any modded chain (e.g. Copper Age Backport), wall brackets, hooks.
- "Hanging Flowers (colour)" = big 1.7.10 flowers (13 colours + Mixed from 1.6.4).
- Recipes added for all hanging plants that had none.

## Colour tab
- ONE tab "PMP: All Plants (colour filter)" with filter buttons on the left side (icons = the mod's flower items / dyes).
- Config: config/pmp_mikexxx/plant_colors.json is created on first start - move ids between lists to re-sort. Delete it to reset.

## Crops
- Brussels Sprout, Burdock, Cassava, Land Cress, Orache, Skirret: 8 growth stages, stages 5-8 are 2 blocks with proper bottom/top textures (1.12.2).
- Corn: 5 stages, stages 3-5 use frame pairs (2/3, 4/5, 6/7) - top block no longer repeats the bottom texture.

## Flowers tab
- Alphabetical by plant name (Azalea, Bellflower, Celosia ...), colours in order: burgundy, red, orange, coral, yellow, green, cyan, blue, royal, purple, magenta, pink, white.

## Aquatic crops (new block class WaterPlantBlock)
- Asian Rice, Centella, Laksa Leaf, Watercress, Water Spinach, Wild Rice: only in water that is exactly 1 block deep (on dirt/mud/clay/sand/gravel).
- Sacred Lotus, Wasabi, Taro: in 1-deep water, OR on soil next to water, OR on mud (anywhere).
- Harvest/drops like land crops. Random-tick growth (light 9+), bone meal, honeycomb = wax, axe = un-wax.

## Immersed plants (new block class WaterPlantBlock)
- Arrow Arum, Common Reed, Duck Potato, European/Simplestem Bur Reed, Grey Sedge, Softstem Bulrush, Water Mannagrass, Yellow Flag.
- Grow as a small sprout in 1-deep water; when mature they become 2 blocks (3 for Common Reed, Grey Sedge, Softstem Bulrush):
  bottom block in the water, the rest above the surface (needs free air above). Textures = the 1.12.2 plants.
- Breaking any part removes the plant (drops once). Waxing / bone meal work.

## Still open
- Land-crop waxing uses the original (unchanged) class logic.
